#include <string.h>
#include <stdio.h>
void interpreter_find(char * chemin,Query * qu,int err);
int fonction_monstre(char *tst,Query * qu);
